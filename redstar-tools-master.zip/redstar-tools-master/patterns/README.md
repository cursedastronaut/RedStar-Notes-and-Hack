## AnGae.dat

The pattern file from Red Star OS 3.0 Desktop.

## angae-010.template

A file structure template for the 010 Editor.

## parse.py

Basic parsing of AnGae.dat files.
