int validate_os(){
    return 1;
}
