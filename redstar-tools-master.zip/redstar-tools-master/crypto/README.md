## jipsam1.ko/jipsam2.ko

Jipsam seems to be a cryptographic algorithmn implemented by the developers of Red Star OS. These modules come from Red Star OS 2.0, they are not available in 3.0.

## pilsung.ko

A kernel module from Red Star OS 3.0 Desktop implementing something like AES.
